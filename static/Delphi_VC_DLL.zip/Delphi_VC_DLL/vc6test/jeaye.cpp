#include "StdAfx.h"
#include ".\jeaye.h"
#include "stdio.h"

CJeaye::CJeaye(void)
{
}

CJeaye::~CJeaye(void)
{
}
int CJeaye::myMax(int x,int y,int* z)
{
	(*z)=x>y?x:y;
	return (*z);
}
int CJeaye::myAdd(int x,int y,int* z)
{
	(*z)=x+y;
	return (*z);
}
void CJeaye::myFree()
{
	delete this;
}