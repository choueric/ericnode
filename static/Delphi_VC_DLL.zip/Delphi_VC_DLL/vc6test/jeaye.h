#pragma once

class CJeaye
{
public:
	CJeaye(void);
	~CJeaye(void);
	virtual int _stdcall myMax(int x,int y,int* z);
	virtual int _stdcall myAdd(int x,int y,int* z);
	virtual void _stdcall myFree();
};

extern   "C"   __declspec(dllexport) CJeaye* CreateClass();